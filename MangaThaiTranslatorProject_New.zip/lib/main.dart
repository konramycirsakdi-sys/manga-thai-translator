import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const MangaThaiTranslatorApp());
}

class MangaThaiTranslatorApp extends StatelessWidget {
  const MangaThaiTranslatorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Manga Thai Translator',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      home: const TranslatorHomePage(),
    );
  }
}

class TranslatorHomePage extends StatefulWidget {
  const TranslatorHomePage({super.key});

  @override
  State<TranslatorHomePage> createState() => _TranslatorHomePageState();
}

class _TranslatorHomePageState extends State<TranslatorHomePage> {
  final TextEditingController _urlController = TextEditingController();
  bool _busy = false;
  String _message = 'วางลิงก์หน้ามังงะ แล้วเลือกการทำงานด้านล่าง';

  @override
  void dispose() {
    _urlController.dispose();
    super.dispose();
  }

  Uri? _readUrl() {
    final raw = _urlController.text.trim();
    if (raw.isEmpty) {
      setState(() => _message = 'กรุณาวางลิงก์ก่อน');
      return null;
    }

    final uri = Uri.tryParse(raw);
    if (uri == null ||
        !uri.hasScheme ||
        (uri.scheme != 'http' && uri.scheme != 'https') ||
        uri.host.isEmpty) {
      setState(() => _message = 'ลิงก์ไม่ถูกต้อง ต้องขึ้นต้นด้วย http:// หรือ https://');
      return null;
    }
    return uri;
  }

  Future<void> _openOriginal() async {
    final uri = _readUrl();
    if (uri == null) return;

    setState(() {
      _busy = true;
      _message = 'กำลังเปิดหน้าเว็บ...';
    });

    try {
      final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!ok) throw Exception('เปิดลิงก์ไม่สำเร็จ');
      if (mounted) {
        setState(() => _message = 'เปิดหน้าเว็บแล้ว');
      }
    } catch (_) {
      if (mounted) setState(() => _message = 'เปิดลิงก์ไม่ได้ ลองตรวจสอบ URL อีกครั้ง');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _translateWebsiteText() async {
    final uri = _readUrl();
    if (uri == null) return;

    // Google Translate website proxy can translate page text on supported sites.
    // It does not OCR/translate manga text embedded inside page images.
    final translated = Uri.https(
      'translate.google.com',
      '/translate',
      <String, String>{
        'sl': 'auto',
        'tl': 'th',
        'u': uri.toString(),
      },
    );

    setState(() {
      _busy = true;
      _message = 'กำลังเปิดหน้าแปลภาษาเว็บ (ไม่ใช่การแปลตัวอักษรในรูปมังงะ)...';
    });

    try {
      final ok = await launchUrl(translated, mode: LaunchMode.externalApplication);
      if (!ok) throw Exception('เปิดหน้าแปลภาษาไม่สำเร็จ');
      if (mounted) {
        setState(() => _message =
            'เปิด Google Translate แล้ว: ใช้แปลข้อความบนเว็บไซต์ได้บางเว็บ แต่ยังไม่แปลตัวอักษรที่ฝังอยู่ในภาพมังงะ');
      }
    } catch (_) {
      if (mounted) setState(() => _message = 'เปิดหน้าแปลภาษาไม่ได้ ลองใหม่อีกครั้ง');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _clear() {
    _urlController.clear();
    setState(() => _message = 'วางลิงก์หน้ามังงะ แล้วเลือกการทำงานด้านล่าง');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Manga Thai Translator'),
        centerTitle: true,
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const Icon(Icons.menu_book_rounded, size: 72),
            const SizedBox(height: 12),
            const Text(
              'ช่วยเปิดมังงะและแปลหน้าเว็บเป็นภาษาไทย',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'วาง URL ของตอนที่ต้องการอ่านในช่องด้านล่าง',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            TextField(
              controller: _urlController,
              keyboardType: TextInputType.url,
              autocorrect: false,
              decoration: const InputDecoration(
                labelText: 'ลิงก์มังงะ',
                hintText: 'https://example.com/chapter-1',
                prefixIcon: Icon(Icons.link),
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: _busy ? null : _translateWebsiteText,
              icon: const Icon(Icons.translate),
              label: const Text('แปลหน้าเว็บเป็นภาษาไทย'),
            ),
            const SizedBox(height: 8),
            OutlinedButton.icon(
              onPressed: _busy ? null : _openOriginal,
              icon: const Icon(Icons.open_in_browser),
              label: const Text('เปิดลิงก์ต้นฉบับ'),
            ),
            const SizedBox(height: 8),
            TextButton.icon(
              onPressed: _busy ? null : _clear,
              icon: const Icon(Icons.clear),
              label: const Text('ล้างลิงก์'),
            ),
            const SizedBox(height: 16),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Icon(Icons.info_outline),
                    const SizedBox(width: 10),
                    Expanded(child: Text(_busy ? 'กำลังทำงาน...' : _message)),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            const Text(
              'หมายเหตุ: เวอร์ชันนี้เป็นชุดเริ่มต้นที่คอมไพล์ได้และช่วยเปิด/แปลข้อความบนเว็บบางเว็บ '
              'ยังไม่สามารถอ่านตัวอักษรที่อยู่ในภาพมังงะแล้วแปลทับภาพทั้งหมดได้ '
              'ฟังก์ชันนั้นต้องเพิ่มระบบ OCR และบริการแปลภาพ/ข้อความ',
              style: TextStyle(fontSize: 13),
            ),
          ],
        ),
      ),
    );
  }
}
