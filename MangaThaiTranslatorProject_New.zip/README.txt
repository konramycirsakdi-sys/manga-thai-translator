Manga Thai Translator - starter project

This is a clean Flutter project intended to build an Android APK with GitHub Actions.

How to use:
1. Extract this ZIP.
2. Upload the contents (pubspec.yaml, lib/, .github/) to the root of a GitHub repository.
   Do NOT upload this ZIP inside the repository; upload the files/folders inside it.
3. Open GitHub > Actions > Build Android APK > Run workflow.
4. When the run succeeds, open the run and download the artifact named:
   manga-thai-translator-apk

Important limitation:
This starter opens the original manga URL and can send supported websites to Google Translate.
It does NOT yet OCR and translate text embedded in manga images. Full image translation needs an OCR
and translation service/API, which is not included in this starter.
