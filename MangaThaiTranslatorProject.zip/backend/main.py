import json
import os
from typing import List

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="Manga Thai Translator API")

# Prefer a language model for context-aware, natural Thai manga dialogue.
# API keys remain on the server and must never be put in the Flutter app.
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-6-astra").strip()
LIBRETRANSLATE_URL = os.getenv("LIBRETRANSLATE_URL", "").strip()
LIBRETRANSLATE_API_KEY = os.getenv("LIBRETRANSLATE_API_KEY", "").strip()

class BatchRequest(BaseModel):
    texts: List[str] = Field(min_length=1, max_length=80)
    source: str = "auto"
    target: str = "th"

@app.get("/health")
async def health():
    return {
        "ok": True,
        "translation_mode": "language_model" if OPENAI_API_KEY else ("libretranslate" if LIBRETRANSLATE_URL else "not_configured"),
    }

def extract_response_text(payload: dict) -> str:
    bits = []
    for item in payload.get("output", []):
        if item.get("type") != "message":
            continue
        for content in item.get("content", []):
            if content.get("type") == "output_text" and isinstance(content.get("text"), str):
                bits.append(content["text"])
    return "\n".join(bits).strip()

async def translate_with_model(client: httpx.AsyncClient, texts: List[str], source: str) -> List[str]:
    source_names = {"auto": "the detected original language (Japanese, Chinese, or English)", "ja": "Japanese", "zh": "Chinese", "en": "English"}
    request_body = {
        "model": OPENAI_MODEL,
        "instructions": (
            "You are a professional manga dialogue translator translating into natural Thai. "
            "Translate each input string into conversational Thai that sounds like real people speaking. "
            "Preserve character personality, emotional tone, humor, context, and relationships. "
            "Use natural Thai pronouns, particles, and sentence endings where context supports them; "
            "avoid stiff word-for-word Thai. Do not add plot details, explanations, speaker labels, or censorship. "
            "Preserve names and meaningful honorifics appropriately. Keep sound effects concise when possible. "
            "Return exactly one Thai translation for each input string, in the same order, as a JSON object "
            "with a translations array. Do not include markdown or commentary."
        ),
        "input": json.dumps({"source_language": source_names.get(source, source), "texts": texts}, ensure_ascii=False),
        "text": {
            "format": {
                "type": "json_schema",
                "name": "manga_translation_batch",
                "strict": True,
                "schema": {
                    "type": "object",
                    "properties": {"translations": {"type": "array", "items": {"type": "string"}}},
                    "required": ["translations"],
                    "additionalProperties": False,
                },
            }
        },
    }
    try:
        response = await client.post(
            "https://api.openai.com/v1/responses",
            headers={"Authorization": f"Bearer {OPENAI_API_KEY}", "Content-Type": "application/json"},
            json=request_body,
        )
        response.raise_for_status()
        payload = response.json()
        text = extract_response_text(payload)
        decoded = json.loads(text)
        translations = decoded.get("translations") if isinstance(decoded, dict) else None
        if not isinstance(translations, list) or len(translations) != len(texts) or not all(isinstance(x, str) for x in translations):
            raise ValueError("Invalid translations array returned by model")
        return translations
    except httpx.HTTPStatusError as exc:
        details = exc.response.text[:1200]
        raise HTTPException(status_code=502, detail=f"Language model API returned {exc.response.status_code}: {details}") from exc
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Natural translation failed: {exc}") from exc

async def translate_with_libre(client: httpx.AsyncClient, texts: List[str], source: str, target: str) -> List[str]:
    if not LIBRETRANSLATE_URL:
        raise HTTPException(status_code=503, detail="ตั้งค่า OPENAI_API_KEY หรือ LIBRETRANSLATE_URL ในเซิร์ฟเวอร์ก่อนใช้งาน")
    results = []
    for text in texts:
        data = {"q": text, "source": source, "target": target, "format": "text"}
        if LIBRETRANSLATE_API_KEY:
            data["api_key"] = LIBRETRANSLATE_API_KEY
        try:
            response = await client.post(LIBRETRANSLATE_URL, data=data)
            response.raise_for_status()
            translated = response.json().get("translatedText")
            if not isinstance(translated, str):
                raise ValueError("missing translatedText")
            results.append(translated)
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"บริการแปลภาษาขัดข้อง: {exc}") from exc
    return results

@app.post("/translate-batch")
async def translate_batch(request: BatchRequest):
    if request.target != "th":
        raise HTTPException(status_code=400, detail="MVP นี้รองรับภาษาเป้าหมายเป็นไทยเท่านั้น")
    if request.source not in {"auto", "ja", "en", "zh"}:
        raise HTTPException(status_code=400, detail="source ต้องเป็น auto, ja, en หรือ zh")
    async with httpx.AsyncClient(timeout=90) as client:
        if OPENAI_API_KEY:
            translations = await translate_with_model(client, request.texts, request.source)
        else:
            translations = await translate_with_libre(client, request.texts, request.source, request.target)
    return {"translations": translations}
