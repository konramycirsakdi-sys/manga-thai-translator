import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:webview_flutter/webview_flutter.dart';

// Emulator: http://10.0.2.2:8000
// Physical device: use your server's LAN IP or an HTTPS deployment.
const String translationBaseUrl = 'http://10.0.2.2:8000';
const int maxImagesPerPage = 80;

void main() => runApp(const MangaTranslatorApp());

class MangaTranslatorApp extends StatelessWidget {
  const MangaTranslatorApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'แปลมังงะไทย',
        theme: ThemeData(colorSchemeSeed: Colors.deepPurple, useMaterial3: true),
        home: const TranslatorHome(),
      );
}

class OcrLine {
  OcrLine(this.text, this.rect);
  final String text;
  final Rect rect;
  String translated = '';
}

class PageImage {
  PageImage({required this.url, required this.width, required this.height});
  final String url;
  final int width;
  final int height;
}

class TranslatorHome extends StatefulWidget {
  const TranslatorHome({super.key});
  @override
  State<TranslatorHome> createState() => _TranslatorHomeState();
}

class _TranslatorHomeState extends State<TranslatorHome> {
  final urlController = TextEditingController();
  WebViewController? webController;
  bool busy = false;
  bool browserLoading = false;
  String status = 'วางลิงก์หน้าตอนมังงะ แล้วกดแปลทั้งหมด';
  String sourceLanguage = 'auto';
  double progress = 0;
  String lastDisplayedUrl = '';
  final List<File> translatedFiles = [];

  Future<void> openWebsite({bool waitForLoad = false}) async {
    final rawUrl = urlController.text.trim();
    final uri = Uri.tryParse(rawUrl);
    if (uri == null || !{'http', 'https'}.contains(uri.scheme) || uri.host.isEmpty) {
      setState(() => status = 'กรุณาใส่ลิงก์เว็บไซต์ที่ขึ้นต้นด้วย https:// หรือ http://');
      return;
    }
    FocusScope.of(context).unfocus();
    final pageLoaded = Completer<void>();
    final controller = WebViewController();
    await controller.setJavaScriptMode(JavaScriptMode.unrestricted);
    await controller.setNavigationDelegate(NavigationDelegate(
      onPageStarted: (_) {
        if (mounted) setState(() { browserLoading = true; status = 'กำลังโหลดเว็บไซต์…'; });
      },
      onProgress: (p) {
        if (mounted) setState(() => progress = p / 100.0);
      },
      onPageFinished: (url) {
        lastDisplayedUrl = url;
        urlController.text = url;
        if (!pageLoaded.isCompleted) pageLoaded.complete();
        if (mounted) setState(() {
          browserLoading = false;
          status = 'เปิดเว็บแล้ว กด “แปลทั้งหมด” เพื่อเริ่มแปลภาพที่พบในหน้านี้';
        });
      },
      onWebResourceError: (error) {
        if (error.isForMainFrame && mounted) {
          setState(() { browserLoading = false; status = 'โหลดเว็บไม่สำเร็จ: ${error.description}'; });
        }
      },
    ));
    setState(() {
      webController = controller;
      browserLoading = true;
      translatedFiles.clear();
      status = 'กำลังเปิดเว็บไซต์…';
    });
    try {
      await controller.loadRequest(uri);
      if (waitForLoad) {
        await pageLoaded.future.timeout(const Duration(seconds: 60));
      }
    } catch (e) {
      if (mounted) setState(() { browserLoading = false; status = 'เปิดเว็บไซต์ไม่ได้: $e'; });
      if (waitForLoad) rethrow;
    }
  }

  Future<List<PageImage>> collectImages() async {
    final controller = webController;
    if (controller == null) throw Exception('กรุณาเปิดเว็บไซต์ก่อน');

    // Scroll through the page to give ordinary lazy-loaded images a chance to appear.
    // This does not bypass logins, paywalls, CAPTCHAs, or anti-bot protections.
    final heightValue = await controller.runJavaScriptReturningResult(
      'document.documentElement.scrollHeight.toString()');
    final pageHeight = int.tryParse(heightValue.toString().replaceAll('"', '')) ?? 6000;
    final steps = (pageHeight / 900).ceil().clamp(1, 35);
    for (var i = 0; i <= steps; i++) {
      await controller.runJavaScript('window.scrollTo(0, ${i * 900});');
      await Future<void>.delayed(const Duration(milliseconds: 130));
    }
    await controller.runJavaScript('window.scrollTo(0, 0);');
    await Future<void>.delayed(const Duration(milliseconds: 350));

    final raw = await controller.runJavaScriptReturningResult(r'''JSON.stringify(
      Array.from(document.images)
        .map((im) => ({url: im.currentSrc || im.src || '', width: im.naturalWidth || 0, height: im.naturalHeight || 0}))
        .filter((im) => /^https?:\/\//i.test(im.url) && im.width >= 180 && im.height >= 200)
        .map((im) => ({url: im.url, width: im.width, height: im.height}))
    )''');
    dynamic decoded;
    try {
      decoded = jsonDecode(raw is String ? raw : raw.toString());
    } catch (_) {
      throw Exception('อ่านรายการรูปจากหน้าเว็บไม่ได้ เว็บไซต์อาจไม่รองรับการอ่านรูปแบบนี้');
    }
    final seen = <String>{};
    final images = <PageImage>[];
    if (decoded is List) {
      for (final item in decoded) {
        if (item is! Map) continue;
        final url = item['url']?.toString() ?? '';
        final width = int.tryParse(item['width'].toString()) ?? 0;
        final height = int.tryParse(item['height'].toString()) ?? 0;
        if (url.isEmpty || !seen.add(url)) continue;
        images.add(PageImage(url: url, width: width, height: height));
        if (images.length >= maxImagesPerPage) break;
      }
    }
    return images;
  }

  Future<File> downloadImage(PageImage image, String pageUrl, int index) async {
    final uri = Uri.parse(image.url);
    // Public image URLs often work. Some sites require session cookies or block direct downloads;
    // this MVP intentionally does not bypass those restrictions.
    final response = await http.get(uri, headers: {
      'Referer': pageUrl,
      'User-Agent': 'Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/126.0 Mobile Safari/537.36',
      'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
    }).timeout(const Duration(seconds: 25));
    if (response.statusCode != 200) {
      throw Exception('ดาวน์โหลดรูปไม่ได้ (HTTP ${response.statusCode})');
    }
    if (response.bodyBytes.length > 25 * 1024 * 1024) throw Exception('ไฟล์รูปใหญ่เกิน 25 MB');
    final tempDir = await getTemporaryDirectory();
    final ext = _extensionFromUri(uri);
    final file = File('${tempDir.path}/manga_src_${DateTime.now().microsecondsSinceEpoch}_$index$ext');
    await file.writeAsBytes(response.bodyBytes, flush: true);
    return file;
  }

  String _extensionFromUri(Uri uri) {
    final p = uri.path.toLowerCase();
    for (final ext in ['.png', '.webp', '.gif', '.jpeg', '.jpg', '.bmp']) {
      if (p.endsWith(ext)) return ext;
    }
    return '.img';
  }

  Future<List<OcrLine>> recognizeText(File file) async {
    final input = InputImage.fromFile(file);
    final scripts = <TextRecognitionScript>[
      TextRecognitionScript.japanese,
      TextRecognitionScript.chinese,
      TextRecognitionScript.latin,
    ];
    final unique = <String, OcrLine>{};
    for (final script in scripts) {
      final recognizer = TextRecognizer(script: script);
      try {
        final result = await recognizer.processImage(input);
        for (final block in result.blocks) {
          for (final line in block.lines) {
            final text = line.text.trim();
            if (text.isEmpty) continue;
            final b = line.boundingBox;
            final rect = Rect.fromLTRB(b.left.toDouble(), b.top.toDouble(), b.right.toDouble(), b.bottom.toDouble());
            final key = '${text.toLowerCase()}_${(b.left / 8).round()}_${(b.top / 8).round()}';
            unique.putIfAbsent(key, () => OcrLine(text, rect));
          }
        }
      } finally {
        await recognizer.close();
      }
    }
    return unique.values.toList();
  }

  Future<List<String>> translateBatch(List<String> texts) async {
    final out = <String>[];
    const chunkSize = 60;
    for (var start = 0; start < texts.length; start += chunkSize) {
      final chunk = texts.skip(start).take(chunkSize).toList();
      final response = await http.post(
        Uri.parse('$translationBaseUrl/translate-batch'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'texts': chunk, 'source': sourceLanguage, 'target': 'th'}),
      ).timeout(const Duration(seconds: 120));
      if (response.statusCode != 200) {
        throw Exception('บริการแปลตอบกลับ ${response.statusCode}: ${response.body}');
      }
      final payload = jsonDecode(response.body) as Map<String, dynamic>;
      out.addAll((payload['translations'] as List).cast<String>());
    }
    return out;
  }

  Future<File> renderTranslatedImage(File source, List<OcrLine> recognized) async {
    final bytes = await source.readAsBytes();
    final codec = await ui.instantiateImageCodec(bytes);
    final frame = await codec.getNextFrame();
    final sourceImage = frame.image;
    final width = sourceImage.width.toDouble();
    final height = sourceImage.height.toDouble();
    final recorder = ui.PictureRecorder();
    final canvas = Canvas(recorder);
    canvas.drawImage(sourceImage, Offset.zero, Paint());

    for (final item in recognized) {
      final rect = Rect.fromLTRB(
        item.rect.left.clamp(0.0, width).toDouble(), item.rect.top.clamp(0.0, height).toDouble(),
        item.rect.right.clamp(0.0, width).toDouble(), item.rect.bottom.clamp(0.0, height).toDouble(),
      ).inflate(3).intersect(Rect.fromLTWH(0, 0, width, height));
      canvas.drawRRect(
        RRect.fromRectAndRadius(rect, const Radius.circular(3)),
        Paint()..color = Colors.white,
      );
      final maxWidth = rect.width.clamp(20.0, width).toDouble();
      var fontSize = (rect.height * 0.78).clamp(8.0, 34.0).toDouble();
      late TextPainter painter;
      while (true) {
        painter = TextPainter(
          text: TextSpan(text: item.translated, style: TextStyle(
            color: Colors.black, fontSize: fontSize, height: 1.0, fontWeight: FontWeight.w500,
          )),
          textDirection: TextDirection.ltr,
          maxLines: 5,
        )..layout(maxWidth: maxWidth);
        if (painter.height <= rect.height + 10 || fontSize <= 8) break;
        fontSize -= 1;
      }
      painter.paint(canvas, Offset(rect.left, rect.top));
    }

    final picture = recorder.endRecording();
    final rendered = await picture.toImage(width.round(), height.round());
    final png = await rendered.toByteData(format: ui.ImageByteFormat.png);
    if (png == null) throw Exception('สร้างภาพผลลัพธ์ไม่สำเร็จ');
    final dir = await getApplicationDocumentsDirectory();
    final output = File('${dir.path}/manga_th_${DateTime.now().millisecondsSinceEpoch}.png');
    await output.writeAsBytes(png.buffer.asUint8List(), flush: true);
    sourceImage.dispose();
    rendered.dispose();
    picture.dispose();
    codec.dispose();
    return output;
  }

  Future<File> translateImage(File imageFile) async {
    final lines = await recognizeText(imageFile);
    if (lines.isEmpty) return imageFile;
    final translations = await translateBatch(lines.map((l) => l.text).toList());
    if (translations.length != lines.length) throw Exception('จำนวนคำแปลไม่ตรงกับข้อความ OCR');
    for (var i = 0; i < lines.length; i++) {
      lines[i].translated = translations[i];
    }
    return renderTranslatedImage(imageFile, lines);
  }

  Future<void> translateAll() async {
    if (busy) return;
    // One-tap flow: if a URL is pasted but not loaded yet, open it and wait for the page.
    final enteredUrl = urlController.text.trim();
    final enteredUri = Uri.tryParse(enteredUrl);
    if (webController == null || (enteredUri != null && enteredUri.host.isNotEmpty && enteredUrl != lastDisplayedUrl)) {
      try {
        await openWebsite(waitForLoad: true);
      } catch (_) {
        return;
      }
    }
    final controller = webController;
    if (controller == null) {
      setState(() => status = 'กรุณาวางลิงก์เว็บไซต์ก่อน');
      return;
    }
    setState(() {
      busy = true;
      progress = 0;
      translatedFiles.clear();
      status = 'กำลังค้นหารูปมังงะในหน้าปัจจุบัน…';
    });
    try {
      final pageUrl = await controller.currentUrl() ?? urlController.text.trim();
      final images = await collectImages();
      if (images.isEmpty) throw Exception('ไม่พบรูปที่น่าจะเป็นหน้ามังงะในหน้านี้ ลองเปิดหน้าตอนที่มีภาพก่อน');
      setState(() => status = 'พบรูป ${images.length} รูป เริ่มแปลทีละหน้า…');
      for (var i = 0; i < images.length; i++) {
        if (!mounted) return;
        setState(() => status = 'กำลังแปลหน้า ${i + 1}/${images.length}…');
        try {
          final original = await downloadImage(images[i], pageUrl, i + 1);
          final translated = await translateImage(original);
          translatedFiles.add(translated);
        } catch (e) {
          // Keep the process moving if one image is unavailable or cannot be decoded.
          debugPrint('Page ${i + 1} skipped: $e');
        }
        if (mounted) setState(() => progress = (i + 1) / images.length);
      }
      if (translatedFiles.isEmpty) {
        throw Exception('แปลไม่ได้ อาจเป็นเพราะเว็บปิดกั้นการดาวน์โหลดภาพ หรือภาพไม่รองรับ');
      }
      setState(() => status = 'เสร็จแล้ว ${translatedFiles.length}/${images.length} หน้า แตะภาพเพื่อขยายหรือแชร์เพื่อบันทึก');
    } catch (e) {
      setState(() => status = 'เกิดข้อผิดพลาด: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> shareAll() async {
    if (translatedFiles.isEmpty) return;
    await Share.shareXFiles(
      translatedFiles.map((f) => XFile(f.path)).toList(),
      text: 'ภาพมังงะที่แปลเป็นภาษาไทย',
    );
  }

  @override
  void dispose() {
    urlController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('แปลมังงะไทยจากลิงก์')),
      body: SafeArea(child: ListView(padding: const EdgeInsets.all(12), children: [
        TextField(
          controller: urlController,
          keyboardType: TextInputType.url,
          textInputAction: TextInputAction.go,
          onSubmitted: (_) => openWebsite(),
          decoration: InputDecoration(
            labelText: 'ลิงก์เว็บไซต์ / หน้าตอนมังงะ',
            hintText: 'https://example.com/manga/chapter-1',
            border: const OutlineInputBorder(),
            prefixIcon: const Icon(Icons.link),
            suffixIcon: IconButton(icon: const Icon(Icons.open_in_browser), onPressed: busy ? null : openWebsite),
          ),
        ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: busy ? null : openWebsite,
          icon: const Icon(Icons.language),
          label: const Text('เปิดเว็บไซต์'),
        ),
        const SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: sourceLanguage,
          decoration: const InputDecoration(labelText: 'ภาษาต้นฉบับ', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'auto', child: Text('ตรวจจับอัตโนมัติ')),
            DropdownMenuItem(value: 'ja', child: Text('ญี่ปุ่น')),
            DropdownMenuItem(value: 'en', child: Text('อังกฤษ')),
            DropdownMenuItem(value: 'zh', child: Text('จีน')),
          ],
          onChanged: busy ? null : (v) => setState(() => sourceLanguage = v ?? 'auto'),
        ),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: Text('เว็บไซต์ต้นฉบับ', style: Theme.of(context).textTheme.titleSmall)),
          if (browserLoading) const SizedBox(width: 80, child: LinearProgressIndicator(minHeight: 3)),
        ]),
        if (webController != null)
          Container(
            height: 360,
            margin: const EdgeInsets.only(top: 6),
            clipBehavior: Clip.antiAlias,
            decoration: BoxDecoration(border: Border.all(color: Theme.of(context).colorScheme.outlineVariant), borderRadius: BorderRadius.circular(10)),
            child: WebViewWidget(controller: webController!),
          )
        else
          Container(
            height: 160,
            alignment: Alignment.center,
            decoration: BoxDecoration(color: Theme.of(context).colorScheme.surfaceContainerHighest, borderRadius: BorderRadius.circular(10)),
            child: const Text('ถ้าวางลิงก์หน้าตอนแล้ว กดแปลทั้งหมดได้เลย'),
          ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: busy || webController == null ? null : translateAll,
          icon: const Icon(Icons.g_translate),
          label: const Text('แปลทั้งหมดเป็นภาษาไทย'),
        ),
        if (busy) ...[
          const SizedBox(height: 8),
          LinearProgressIndicator(value: progress == 0 ? null : progress),
        ],
        const SizedBox(height: 8),
        Text(status, style: Theme.of(context).textTheme.bodyMedium),
        if (translatedFiles.isNotEmpty) ...[
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: Text('ผลการแปล (${translatedFiles.length} หน้า)', style: Theme.of(context).textTheme.titleMedium)),
            TextButton.icon(onPressed: shareAll, icon: const Icon(Icons.save_alt), label: const Text('แชร์ / บันทึกทั้งหมด')),
          ]),
          for (var i = 0; i < translatedFiles.length; i++) ...[
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Card(clipBehavior: Clip.antiAlias, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Padding(padding: const EdgeInsets.all(8), child: Text('หน้า ${i + 1}')),
                InteractiveViewer(minScale: 0.6, maxScale: 4, child: Image.file(translatedFiles[i], fit: BoxFit.contain)),
                TextButton.icon(
                  onPressed: () => Share.shareXFiles([XFile(translatedFiles[i].path)], text: 'มังงะภาษาไทย หน้า ${i + 1}'),
                  icon: const Icon(Icons.ios_share), label: const Text('บันทึกหรือแชร์หน้านี้'),
                ),
              ])),
            ),
          ],
        ],
        const SizedBox(height: 12),
        const Text(
          'ข้อจำกัด: ทำงานกับรูปภาพที่เว็บแสดงเป็นแท็กภาพทั่วไป และดาวน์โหลดได้ตามปกติเท่านั้น ไม่ข้ามระบบเข้าสู่ระบบ การจ่ายเงิน CAPTCHA หรือมาตรการป้องกันของเว็บไซต์ การปิดข้อความเดิมใช้พื้นสีขาวจึงอาจบังฉากหลังได้',
          style: TextStyle(fontSize: 12),
        ),
      ])),
    );
  }
}
