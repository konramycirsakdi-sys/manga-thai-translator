# Manga Thai Translator — URL-first Android MVP

แอป Flutter สำหรับวาง URL เว็บไซต์มังงะ เปิดหน้าเว็บในแอป และทดลองแปลข้อความในภาพเป็นภาษาไทยทีละหลายภาพ

## ฟีเจอร์
- วางลิงก์ `http://` หรือ `https://` แล้วเปิดเว็บไซต์ในเบราว์เซอร์ภายในแอป
- ผู้ใช้เลื่อนไปยังหน้าตอนที่ต้องการเอง
- สแกน DOM ของหน้าปัจจุบันเพื่อรวบรวมภาพ `<img>` ที่โหลดแล้ว (พยายามเลื่อนเพื่อโหลด lazy images)
- ดาวน์โหลดภาพที่เปิดให้เข้าถึงได้ตามปกติ แล้ว OCR ด้วย ML Kit สำหรับญี่ปุ่น จีน และ Latin/อังกฤษ
- ส่งข้อความหลายรายการไปแปลเป็นภาษาไทย โดยใช้โมเดลภาษาสำหรับสำนวนสนทนาธรรมชาติเมื่อกำหนด OpenAI API key ไว้ใน backend
- วางคำแปลบนภาพและแชร์/บันทึกผลเป็น PNG

## ข้อจำกัดและการใช้งานอย่างรับผิดชอบ
- เป็น MVP ไม่ใช่ Google Translate เต็มรูปแบบ และยังไม่ได้ยืนยันความเข้ากันได้กับทุกเว็บไซต์
- ใช้กับหน้าเว็บที่คุณมีสิทธิ์เข้าถึงและมีสิทธิ์แปล/ใช้งานเนื้อหาเท่านั้น
- ไม่ข้าม paywall, login, CAPTCHA, DRM หรือมาตรการป้องกันของเว็บไซต์ หากดาวน์โหลดรูปไม่ได้ แอปจะแจ้ง/ข้ามภาพนั้น
- รองรับภาพที่แสดงผ่านแท็ก `<img>` เป็นหลัก; canvas, CSS background, reader ที่วาดภาพเอง, เว็บที่เปลี่ยน URL แบบชั่วคราว หรือเว็บที่ต้องใช้ cookies ในการดาวน์โหลดอาจใช้ไม่ได้
- คำว่า “แปลทั้งหมด” หมายถึงรูปภาพที่ตรวจพบในหน้าปัจจุบัน สูงสุด 80 รูปต่อรอบ ไม่ได้ตามลิงก์ไปทุกตอนของเว็บไซต์
- การลบข้อความเดิมใช้แผ่นสีขาว ไม่ได้เติมฉากหลังด้วย AI จึงอาจทับเส้นภาพ/พื้นหลัง และตำแหน่งคำแปลอาจต้องปรับ
- แปลเป็นภาษาธรรมชาติได้ดีขึ้นเมื่อใช้โมเดลภาษา แต่ความแม่นยำขึ้นกับภาพ OCR บริบท และโมเดล
- หากเผยแพร่ให้ผู้อื่นใช้ ควรเพิ่ม authentication, rate limit, HTTPS, logging ที่ไม่เก็บเนื้อหาส่วนตัว และจำกัดค่าใช้จ่ายของ API

## 1. เครื่องมือ
ติดตั้ง Flutter SDK และ Android Studio จากแหล่งทางการ แล้วตรวจสอบ:
```bash
flutter doctor
```

## 2. เตรียมแอป Flutter
แตก ZIP จากนั้นใน root ของโปรเจกต์รัน:
```bash
flutter create --platforms=android .
flutter pub get
```

ตรวจ Android permission ใน `android/app/src/main/AndroidManifest.xml` ให้มีภายใน `<manifest>`:
```xml
<uses-permission android:name="android.permission.INTERNET" />
```

**เพิ่ม native OCR dependencies สำหรับภาษาญี่ปุ่นและจีน** หลัง `flutter create` เปิด `android/app/build.gradle` แล้วเพิ่มในบล็อก `dependencies`:
```gradle
implementation 'com.google.mlkit:text-recognition-japanese:16.0.1'
implementation 'com.google.mlkit:text-recognition-chinese:16.0.1'
```
ถ้าโปรเจกต์ใช้ `android/app/build.gradle.kts` ให้ใช้รูปแบบ:
```kotlin
implementation("com.google.mlkit:text-recognition-japanese:16.0.1")
implementation("com.google.mlkit:text-recognition-chinese:16.0.1")
```
จากนั้นรัน `flutter pub get` อีกครั้ง หาก build ล้มเหลว ให้ตรวจเวอร์ชัน Android Gradle Plugin และ compile SDK ที่ plugin ต้องการ

สำหรับทดสอบ backend แบบ HTTP บน emulator อาจต้องเพิ่ม `android:usesCleartextTraffic="true"` ในแท็ก `<application>` ของ Manifest **เฉพาะ debug/dev** (อย่าใช้กับ release ที่เผยแพร่) สำหรับใช้งานจริงให้ใช้ HTTPS.

## 3. ตั้งค่า backend สำหรับแปลธรรมชาติ
แนะนำให้ตั้งค่า `OPENAI_API_KEY` ไว้บนเซิร์ฟเวอร์ ไม่ใช่ในแอป และห้ามใส่ key ลง source code หรือแชร์ ZIP ที่มี key:
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

กำหนด environment variables:
```bash
# แนะนำ: แปลแบบคำนึงถึงบริบท/น้ำเสียง
export OPENAI_API_KEY="your-key"
export OPENAI_MODEL="gpt-6-astra"

# หรือใช้ LibreTranslate เป็นทางเลือก (ภาษาพูด/บริบทอาจด้อยกว่า)
# export LIBRETRANSLATE_URL="https://your-translation-server.example/translate"
# export LIBRETRANSLATE_API_KEY=""

uvicorn main:app --host 0.0.0.0 --port 8000
```
ถ้ารุ่นโมเดลที่ตั้งค่าไม่มีสิทธิ์ใช้งาน ให้เปลี่ยน `OPENAI_MODEL` เป็นโมเดลที่บัญชีของคุณรองรับ ดูคู่มือ API ทางการของผู้ให้บริการ

## 4. ชี้แอปไปยัง backend
แก้ `translationBaseUrl` ที่ต้นไฟล์ `lib/main.dart`:
- Android Emulator: `http://10.0.2.2:8000`
- มือถือจริงใน Wi-Fi เดียวกับคอม: `http://IP-ของคอม:8000`
- เซิร์ฟเวอร์ใช้งานจริง: URL HTTPS ของคุณ

ไม่ควรเปิด backend ที่ไม่มี authentication ต่อสาธารณะโดยตรง

## 5. สร้าง APK และติดตั้ง
```bash
flutter build apk --release
```
APK อยู่ที่ `build/app/outputs/flutter-apk/app-release.apk`.

ส่งไฟล์ไป Android แล้วเปิดเพื่อติดตั้ง หรือใช้ USB debugging:
```bash
flutter install
```

## 6. วิธีใช้
1. เปิดแอปและวาง URL โดยตรงของหน้าตอนมังงะที่เข้าถึงได้ตามปกติ
2. เลือกภาษาเดิมหรือเลือก “ตรวจจับอัตโนมัติ”
3. กด “แปลทั้งหมดเป็นภาษาไทย” — แอปจะเปิด URL ให้เองและเริ่มแปลหลังหน้าเว็บโหลดเสร็จ
4. ถ้าลิงก์เป็นหน้าแรกของเว็บ ให้เปิดเว็บไซต์ก่อน แล้วเลื่อนไปยังหน้าตอนที่ต้องการใน WebView
5. ดูผลลัพธ์ด้านล่างและกดแชร์/บันทึกภาพ

## 7. ทดสอบ backend
เมื่อเซิร์ฟเวอร์ทำงาน ลองเปิด `/health` แล้วตรวจว่าขึ้น `translation_mode: language_model` หรือ `libretranslate` ตามที่ตั้งค่าไว้
